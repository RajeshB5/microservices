package com.curd.fullStackBootReact;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FullStackBootReactApplication {

	public static void main(String[] args) {
		SpringApplication.run(FullStackBootReactApplication.class, args);
	}

}
